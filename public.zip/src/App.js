import Dashboard from "@components/Dashboard";
import Quiz from "@components/Quiz";
import "@css/App.css";
import { Route, Routes } from "react-router-dom";

function App() {
  return (
    <>
      <Routes>
        <Route path="/" element={<Dashboard/>}/>
        <Route path="/questions/:amount" element={<Quiz/>}/>
      </Routes>
    </>
  );
}

export default App;
