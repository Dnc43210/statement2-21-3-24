import { decode } from "html-entities";
import React, { useEffect, useState } from "react";

function Question(props) {
  const [options, setOptions] = useState([props.question.correct_answer, ...props.question.incorrect_answers]);
  let question = props.question;

//   let correct = question.correct_answer;
  const allOptions = [question.correct_answer, ...question.incorrect_answers];

  useEffect(() => {
    // console.log(question)
    // Shuffle the combined options array
    const shuffledOptions = shuffleArray(allOptions);
    setOptions(shuffledOptions);
    console.log(allOptions);
    console.log(shuffledOptions);     

    // eslint-disable-next-line
  }, [props.question]);

  // Function to shuffle an array (using Fisher-Yates algorithm)
  function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
  }

  return (
    <>
      <p>{decode(question.question)}</p>
      {options.map((option, i) => (
        <>
          <input type="radio" name={"q"+props.qno} id={`q${props.qno}o${i}`} />
          <label htmlFor={`q${props.qno}o${i}`}>{option}</label>
          <br />
        </>
      ))}
    </>
  );
}

export default Question;
