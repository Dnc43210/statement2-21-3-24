import React from "react";
import Navbar from "./Navbar";
import { Link } from "react-router-dom";

let questionnaires = [
  {
    name: "Demo quiz",
    amount: 5,
  },
  {
    name: "Quiz",
    amount: 15,
  },
];
export default function Dashboard() {
  return (
    <div>
      <Navbar />
      <p className="font-medium text-3xl px-12 pt-12 capitalize" >Questionnaires</p>
      <div className="grid grid-cols-1 gap-x-8 gap-y-10 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 mx-4 p-7">
        {questionnaires.map((questionnaire, i) => (
          <Link
            to={`/questions/${questionnaire.amount}`}
            key={`card${i}`}
            class="max-w-sm  rounded-3xl overflow-hidden hover:shadow-2xl duration-500 border bg-slate-200"
          >
            <img
              class="w-full object-cover h-[60%] sm:h-auto"
              src="https://t4.ftcdn.net/jpg/04/39/13/37/360_F_439133763_FrLdhZsd5aGC23r9ATARuKJBr8ifZjIe.jpg"
              alt="Sunset in the mountains"
            />
            <div class="px-6 py-1 md:py-4">
              <p class="font-bold text-sm mb-2 md:text-xl">{questionnaire.name}</p>
            </div>
            <div class="px-6 pb-2">
              <span class="inline-block bg-gray-100 rounded-full px-3 py-1 text-xs md:text-sm font-semibold text-gray-700 mr-2 mb-2 capitalize">
                {"questions: "+questionnaire.amount}
              </span>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
