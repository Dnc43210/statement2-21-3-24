import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import Navbar from "./Navbar";
// import axios from "axios";
import questionBank from "@utils/questions.json";
import Question from "./Question";

export default function Quiz() {
  const [questions, setQuestions] = useState(questionBank.results);
  const [currentQuestion, setCurrentQuestion] = useState(0);

  const { amount } = useParams();

  const getRandomQuestions = (array, numQuestions) => {
    let shuffled = array.slice().sort(() => Math.random() - 0.5);
    return shuffled.slice(0, numQuestions);
  };

  useEffect(() => {
    // Shuffle the array of questions
    // console.log(questionBank.results)
    const shuffledQuestions = getRandomQuestions(questionBank.results, amount);

    // Set the selected questions as the component's state
    setQuestions(shuffledQuestions);

    // eslint-disable-next-line
  }, []);

  return (
    <div className="">
      <Navbar />
      <Question question={questions[currentQuestion]} qno={currentQuestion}/>

      <button
        className="border rounded-lg p-2 bg-blue-500 text-white disabled:bg-gray-500"
        onClick={() => {
          let current = currentQuestion;
          setCurrentQuestion(current - 1);
        }}
        // eslint-disable-next-line
        disabled = {currentQuestion==0?true:false}
      >
        Previous
      </button>
      <button
        className="border rounded-lg p-2 bg-blue-500 text-white disabled:bg-gray-500"
        onClick={() => {
          let current = currentQuestion;
          // eslint-disable-next-line
          if((current+1)==amount)
          setCurrentQuestion(current);
          else
          setCurrentQuestion(current + 1);
        }}
        // eslint-disable-next-line
        disabled = {currentQuestion==(amount-1)}
      >
        Submit&Next</button>
    </div>
  );
}
